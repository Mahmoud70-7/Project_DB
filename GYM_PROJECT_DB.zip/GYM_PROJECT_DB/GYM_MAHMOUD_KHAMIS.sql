create database GYM;
use GYM;
create table Members  ( Member_ID int(15) primary key,NameMember varchar(20),JoinDate date,SubscriptionType varchar(15));
show tables;
create table Trainers ( Trainer_ID int(15) primary key,
NameTrainer varchar(20),
Specialty varchar(15)
);


INSERT INTO Members (Member_ID, NameMember, JoinDate, SubscriptionType) VALUES
(1, 'John Smith', '2025-01-05', 'Monthly'),
(2, 'Sarah Johnson', '2025-02-10', 'Yearly'),
(3, 'Michael Brown', '2025-03-15', 'Monthly'),
(4, 'Emily Davis', '2025-04-20', 'Yearly'),
(5, 'David Wilson', '2025-01-25', 'Monthly'),
(6, 'Lisa Anderson', '2025-02-28', 'Yearly'),
(7, 'James Taylor', '2025-03-10', 'Monthly'),
(8, 'Rachel White', '2025-04-05', 'Yearly'),
(9, 'Thomas Clark', '2025-01-12', 'Monthly'),
(10, 'Anna Martinez', '2025-02-18', 'Yearly');


CREATE TABLE Sessions (
    Session_ID INT(15) PRIMARY KEY,
    Member_ID INT(15),
    Trainer_ID INT(15),
    SessionDate DATE,
    SessionTime TIME,
    Duration INT, 
    FOREIGN KEY (Member_ID) REFERENCES Members(Member_ID),
    FOREIGN KEY (Trainer_ID) REFERENCES Trainers(Trainer_ID) 
);
show tables;

ALTER TABLE Sessions ADD SessionName char(20) ;
USE GYM;

INSERT INTO Sessions ( SessionName) VALUES
(1, 'Fitness Bootcamp'),
(2, 'Pilates Basics'),
(3, 'Endurance Run'),
(4, 'Muscle Building'),
(5, 'Flexibility Class'),
(6, 'HIIT Workout'),
(7, 'Zumba Dance'),
(8, 'Body Sculpting'),
(9, 'Strength Circuit'),
(10, 'Meditation Session');


CREATE TABLE Equipments (
    Equipment_ID INT(15) PRIMARY KEY,
    EquipmentName VARCHAR(20),
    PurchaseDate DATE,
    Status  VARCHAR(15)
);
drop table Trainer;
UPDATE Sessions SET SessionName = 'Weightlifting' WHERE Session_ID = 1;
UPDATE Sessions SET SessionName = 'Yoga' WHERE Session_ID = 2;
UPDATE Sessions SET SessionName = 'Cardio' WHERE Session_ID = 3;
UPDATE Sessions SET SessionName = 'Strength' WHERE Session_ID = 4;
UPDATE Sessions SET SessionName = 'Weightlifting' WHERE Session_ID = 5;
UPDATE Sessions SET SessionName = 'Yoga' WHERE Session_ID = 6;
UPDATE Sessions SET SessionName = 'Cardio' WHERE Session_ID = 7;
UPDATE Sessions SET SessionName = 'Strength' WHERE Session_ID = 8;
UPDATE Sessions SET SessionName = 'Weightlifting' WHERE Session_ID = 9;
UPDATE Sessions SET SessionName = 'Yoga' WHERE Session_ID = 10;

INSERT INTO Trainers (Trainer_ID, TrainerName, Specialty) VALUES
(1, 'Robert Lee', 'Weightlifting'),
(2, 'Jessica Moore', 'Yoga'),
(3, 'Daniel Garcia', 'Cardio'),
(4, 'Laura Young', 'Strength'),
(5, 'Chris Allen', 'Weightlifting'),
(6, 'Megan Scott', 'Yoga'),
(7, 'Brian Turner', 'Cardio'),
(8, 'Kelly Adams', 'Strength'),
(9, 'Paul Evans', 'Weightlifting'),
(10, 'Nicole King', 'Yoga');

INSERT INTO Sessions (Session_ID, Member_ID, Trainer_ID, SessionDate, SessionTime, Duration) VALUES
(1, 1, 1, '2025-05-01', '09:00:00', 60),
(2, 2, 2, '2025-05-02', '10:00:00', 45),
(3, 3, 3, '2025-05-03', '11:00:00', 60),
(4, 4, 4, '2025-05-04', '08:00:00', 50),
(5, 5, 5, '2025-05-05', '09:30:00', 45),
(6, 6, 6, '2025-05-06', '10:30:00', 60),
(7, 7, 7, '2025-05-07', '11:00:00', 55),
(8, 8, 8, '2025-05-08', '08:30:00', 45),
(9, 9, 9, '2025-05-09', '09:00:00', 60),
(10, 10, 10, '2025-05-10', '10:00:00', 50);


INSERT INTO Equipments (Equipment_ID, EquipmentName, PurchaseDate, Status) VALUES
(1, 'Treadmill', '2024-01-15', 'Good'),
(2, 'Stationary Bike', '2024-02-20', 'Good'),
(3, 'Dumbbells', '2024-03-10', 'Needs Repair'),
(4, 'Yoga Mat', '2024-04-05', 'Good'),
(5, 'Kettlebell', '2024-05-12', 'Good'),
(6, 'Rowing Machine', '2024-06-18', 'Needs Repair'),
(7, 'Bench Press', '2024-07-25', 'Good'),
(8, 'Pull-Up Bar', '2024-08-30', 'Good'),
(9, 'Resistance Bands', '2024-09-15', 'Good'),
(10, 'Elliptical', '2024-10-20', 'Needs Repair');

select * from Equipments


-- الاوامر 

# select * from Trainers
# select * from Members
# select * from Equipments



SELECT * FROM Members WHERE SubscriptionType = 'Monthly';

SELECT * FROM Members WHERE NameMember like '%';

select * from Equipments Where  status = "Needs Repair";

select SessionName as sn , SessionDate,TrainerName as tn , NameMember as mn from Sessions as s join Members as m on s. Member_ID = m. Member_ID
join Trainers as t on s.Trainer_ID = t.Trainer_ID ;

DELETE FROM Sessions
WHERE Session_ID >= 31;

SELECT * FROM Sessions
WHERE SessionDate = '2025-05-01' AND Duration > 50;


SELECT Status, COUNT(Equipment_ID) AS EquipmentCount
FROM Equipments
GROUP BY Status;

USE GYM;


SELECT T.Trainer_ID, T.TrainerName, AVG(S.Duration) AS AverageDuration
FROM Trainers T
JOIN Sessions S ON T.Trainer_ID = S.Trainer_ID
GROUP BY T.Trainer_ID, T.TrainerName
ORDER BY AverageDuration DESC;

SELECT T.Trainer_ID, T.TrainerName, AVG(S.Duration) AS AverageDuration
FROM Trainers T
JOIN Sessions S ON T.Trainer_ID = S.Trainer_ID
GROUP BY T.Trainer_ID, T.TrainerName
ORDER BY AverageDuration ;


CREATE USER IF NOT EXISTS 'admin_gym'@'localhost' IDENTIFIED BY 'Admin@123';
GRANT ALL PRIVILEGES ON GYM.* TO 'admin_gym'@'localhost';

CREATE USER IF NOT EXISTS 'trainer_gym'@'localhost' IDENTIFIED BY 'Trainer@123';
GRANT SELECT, INSERT, UPDATE ON GYM.Sessions TO 'trainer_gym'@'localhost';
GRANT SELECT ON GYM.Members TO 'trainer_gym'@'localhost';
GRANT SELECT ON GYM.Equipments TO 'trainer_gym'@'localhost';

CREATE USER IF NOT EXISTS 'member_gym'@'localhost' IDENTIFIED BY 'Member@123';
GRANT SELECT ON GYM.Sessions TO 'member_gym'@'localhost';
GRANT SELECT ON GYM.Trainers TO 'member_gym'@'localhost';

use GYM;
select * from Members;
